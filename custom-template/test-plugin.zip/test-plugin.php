<?php
/**
* Plugin Name: test-plugin
* Plugin URI: https://dev-ai-college-assists.pantheonsite.io/
* Description: Test.
* Version: 0.1
* Author: Gordon and Claire
* Author URI: https://dev-ai-college-assists.pantheonsite.io/
**/